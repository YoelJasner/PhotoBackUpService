package com.example.seanz.somrproject;

/**
 * data object for the progress bar
 */
public class ProgressBarObj {

    //max value of the progress
    private int maxVal;
    //current value of the progress
    private int currVal;

    /**
     * class constructor
     */
    public ProgressBarObj() {
        this.maxVal = 0;
        this.currVal = 0;
    }

    /**
     * gettier method for the max value of the progress
     * @return the max value of the progress
     */
    public int getMaxVal() {
        return this.maxVal;
    }

    /**
     * getter method for the current value of the progress
     * @return hte current value of the progress
     */
    public int getCurrVal() {
        return this.currVal;
    }

    /**
     * setter method for the max value of the progress
     * @param val the max value of the progress
     */
    public void setMaxVal(int val) {
        this.maxVal = val;
    }

    /**
     * method for incrementing the progress in one step
     */
    public void incrCurrVal() {
        this.currVal++;
    }

    /**
     * method for initializing the progress to the start
     */
    public void reset() {
        this.currVal = 0;
    }
}
