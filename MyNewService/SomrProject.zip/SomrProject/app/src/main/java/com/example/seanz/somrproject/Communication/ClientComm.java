package com.example.seanz.somrproject.Communication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.example.seanz.somrproject.PhotosManager;
import com.example.seanz.somrproject.ProgressBarObj;
import com.example.seanz.somrproject.ProgressBarObjDisplay;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * class for handling the communication of the app
 */
public class ClientComm {
    private Socket socket;
    private int port;
    private String ipAdrress;
    private PhotosManager photosM;

    private ProgressBarObjDisplay progBarDis;

    /**
     * class constructor
     * @param pm photos manager object
     * @param port port number
     * @param ip ip address
     * @param pbd progress bar display object
     */
    public ClientComm(PhotosManager pm, int port, String ip, ProgressBarObjDisplay pbd) {
        this.port = port;
        this.ipAdrress = ip;
        this.photosM = pm;
        this.progBarDis = pbd;

    }

    /**
     * connecting to the communication channel
     * @return true if connected, false otherwise
     */
    public boolean Connect() {
        try {
            InetAddress addr = InetAddress.getByName(this.ipAdrress);
            this.socket = new Socket(addr, this.port);
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }

    /**
     * transferring the photos using the communication channel
     */
    public void transferData() {
        new Thread() {
            @Override
            public void run() {
                try {
                    sendPhotos();
                } catch (Exception e) { }
            }
        }.start();
    }

    /**
     * method containing the main logic of sending the photos on the communication channel
     * @throws Exception
     */
    private void sendPhotos() throws Exception{

        this.progBarDis.startNewCount();
        OutputStream outStream = this.socket.getOutputStream();

        File[] picsToSend = this.photosM.getPhotos();

        if (picsToSend == null) return;

        this.progBarDis.setMaxVal(picsToSend.length);

        for (File photo : picsToSend) {
            try
            {
                this.progBarDis.incrementCount();

                FileInputStream fis = new FileInputStream(photo);
                Bitmap bm = BitmapFactory.decodeStream(fis);
                byte[] imgbyte = getBytesFromBitmap(bm);
                String name = photo.getName();

                outStream.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(name.length()).array());
                outStream.flush();
                outStream.write(name.getBytes());
                outStream.flush();
                outStream.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(imgbyte.length).array());
                outStream.flush();
                outStream.write(imgbyte);
                outStream.flush();

            }
            catch (Exception e) { }
        }
        this.progBarDis.finishCount();
    }

    /**
     * method for convering BitMap of a photo to byte array
     * @param bitmap the bitmap to convert
     * @return byte array
     */
    private byte[] getBytesFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return stream.toByteArray();
    }
}
