package com.example.seanz.somrproject;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

/**
 * class of object responsible of displaying a progress bar
 */
public class ProgressBarObjDisplay {

    //the progress bar data class
    private ProgressBarObj progressBar;
    //notification builder
    private NotificationCompat.Builder builder;
    //notification manager
    private NotificationManager manager;

    /**
     * class constructor, sets the display of the progress bar
     * @param pbo the progress bar data object
     * @param context the context
     */
    public ProgressBarObjDisplay(ProgressBarObj pbo, Context context) {
        this.progressBar = pbo;
        NotificationChannel progressChannel = new NotificationChannel("progressId", "Progress", NotificationManager.IMPORTANCE_DEFAULT);
        builder = new NotificationCompat.Builder(context, "transfer")
                .setSmallIcon(R.drawable.icon_information)
                .setContentTitle("Transferring Photos")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setChannelId("progressId")
                .setContentText("Transferring");

        // Add as notification
        manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.createNotificationChannel(progressChannel);
    }

    /**
     * setter for the max value of the progress bar
     * @param maxVal the max value
     */
    public void setMaxVal(int maxVal) {
        this.progressBar.setMaxVal(maxVal);
    }

    /**
     * advancing the progress bar display in one step
     */
    public void incrementCount() {
        this.progressBar.incrCurrVal();
        builder.setProgress(progressBar.getMaxVal(), progressBar.getCurrVal(), false);
        builder.setContentText(progressBar.getCurrVal() + " out of " + progressBar.getMaxVal());
        manager.notify(0, builder.build());
    }

    /**
     * starting a new progress bar notification display
     */
    public void startNewCount() {
        builder.setProgress(0, 0, false);
        builder.setContentText("Starting Transfer");
        manager.notify(0, builder.build());
    }

    /**
     * ending the current notification progress bar display
     */
    public void finishCount() {
        builder.setProgress(0, 0, false);
        builder.setContentText("Finished Sending Photos");
        manager.notify(0, builder.build());
    }

}
