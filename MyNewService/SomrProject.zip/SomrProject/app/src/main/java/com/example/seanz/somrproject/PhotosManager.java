package com.example.seanz.somrproject;

import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;

/**
 * class representing the logic for photos extraction from the storage
 */
public class PhotosManager {

    /**
     * method returning array of photos from the phone storage
     * @return array of photos (Files)
     */
    public File[] getPhotos() {
        File dcim = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM + "/Camera");
        if (dcim == null) {
            return null;
        }
        List<File> filesInDcim = new ArrayList<File>();
        this.recursiveGetAllFilesInDir(dcim, filesInDcim);
        List<File> photosInDcim = new ArrayList<File>();
        //filtering the photos from all the files
        for(File file : filesInDcim) {
            String fileName = file.getName();
            if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg") || fileName.endsWith(".png") ||
                    fileName.endsWith(".bmp") || fileName.endsWith(".gif"))
                photosInDcim.add(file);
        }

        return photosInDcim.toArray(new File[0]);
    }

    /**
     * recursive method for extracting the files from certain directory and its subdirectories
     * @param dir directory path
     * @param files list of files to put the files into
     */
    public void recursiveGetAllFilesInDir(File dir, List<File> files) {
        File[] filesInCurrentDir = dir.listFiles();
        for (File file : filesInCurrentDir) {
            if (file.isFile()) {
                files.add(file);
            } else {
                if (file.isDirectory()) {
                    recursiveGetAllFilesInDir(file.getAbsoluteFile(), files);
                }
            }
        }
    }
}
